n, m = map(int, input().split())
result = 0 if n == 1 and m == 1 else n*m-1
print(result)